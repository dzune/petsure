﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(test_ur_iq.Startup))]
namespace test_ur_iq
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
