﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace test_ur_iq.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
            
        }

        /// <summary>
        /// This function returns the shape
        /// </summary>
        /// <param name="intSide1">Left Side</param>
        /// <param name="intSide2">Top Side</param>
        /// <param name="intSide3">Right Side</param>
        /// <param name="intSide4">Bottom Side</param>
        /// <returns></returns>
        public ActionResult GetMyShape(string Side1, string Side2, string Side3, string Side4)
        {
            
            int intSide1 = Convert.ToInt32((Side1==""?"0":Side1));
            int intSide2 = Convert.ToInt32((Side2==""?"0":Side2));
            int intSide3 = Convert.ToInt32((Side3==""?"0":Side3));
            int intSide4 = Convert.ToInt32((Side4==""?"0":Side4));
            string strShape = "";
            if (intSide1 == 0 || intSide3 == 0 || intSide2 == 0 || intSide4 == 0)
            {
                strShape = "";
                TempData["message"] = strShape;
                return RedirectToAction("index");
                  
            }
    
            if (intSide1 != intSide3 || intSide2 != intSide4)
            {
                strShape = "Neither a Square or a Rectangle";
            }
            else if ((intSide1 == intSide3 && intSide2 == intSide4) && (intSide1 != intSide2))
            {
                strShape = "Rectangle";
            }
            else
            {
                strShape = "Square";
            }

            TempData["message"]= strShape;
            return RedirectToAction("index");
            
        }
    }
}